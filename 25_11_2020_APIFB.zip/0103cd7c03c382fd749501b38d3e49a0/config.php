<?php
$login['a'] = 'pass'; //  админ
?>