<?php
header('Location: main/index.php');
?>